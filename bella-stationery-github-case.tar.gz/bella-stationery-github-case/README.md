# Bella Stationery — Retail Profitability Case

[![CI](https://github.com/<your-user>/<your-repository>/actions/workflows/ci.yml/badge.svg)](https://github.com/<your-user>/<your-repository>/actions/workflows/ci.yml) [![Python](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/) [![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

## Business context
Bella Stationery is a national retailer of office supplies and premium stationery. Revenue has grown, but profit has not kept pace. This case investigates the erosion of profitability across products, logistics, regions, customer segments, discounts and returns.

## Objective
Turn transactional sales data into decision-ready evidence: identify where value is destroyed, which areas deserve selective growth, and which commercial or operational guardrails can restore margin.

## Key results
- Revenue: **R$14.92M**
- Profit: **R$1.52M**
- Profit margin: **10.2%**
- 8,399 sales rows and 5,000+ unique orders
- The analysis explicitly flags dates after **2026-08-08** as future-dated records instead of silently deleting them.

## Main decision questions
1. Which products and sub-categories grow sales but destroy profit?
2. How do discounts, shipping costs and returns affect margin?
3. Which regions, segments and shipping methods should be prioritized?
4. What actions can restore profitability without stopping healthy growth?

## Repository map
```text
data/raw/              Original workbook
data/processed_sales.csv  Flat processed extract
src/                   Reusable loading and profitability functions
notebooks/             Notebook guidance and narrative entry point
reports/               Self-contained dashboard and brand asset
tests/                 Unit tests
.github/workflows/     Continuous integration
Dockerfile             Reproducible runtime
Makefile               Common commands
```

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
make all
```

Then open `reports/dashboard.html` in a browser. The dashboard has no external CDN dependency and runs offline.

## Reproducible pipeline
1. Load the source workbook with explicit date parsing.
2. Preserve all records and add a `Futuro` flag for dates after 2026-08-08.
3. Calculate revenue, profit, margin, shipping, discount and return metrics.
4. Aggregate performance by category, sub-category, shipping method, region and segment.
5. Generate a portable HTML dashboard.
6. Run unit tests in local development and GitHub Actions.

## Recommended actions
- Establish a minimum margin floor by sub-category and block promotions below it.
- Review high-discount / negative-profit transactions before scaling campaigns.
- Negotiate freight and test service-level thresholds for weak shipping methods.
- Reprice or rationalize sub-categories with persistent negative profit.
- Monitor returns as a quality and product-fit signal, not only as a logistics metric.

## Limitations and next steps
The source data does not include acquisition channel, inventory, competitor prices or product-level cost fields beyond the recorded transaction economics. Future work should add cohort retention, price elasticity, causal promotion analysis, forecast backtesting and explainable predictive models.

## Authorship
Prepared by **Luciana Gomes Dias Manfredi**.
